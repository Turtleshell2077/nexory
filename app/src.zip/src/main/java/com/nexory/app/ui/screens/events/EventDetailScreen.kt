package com.nexory.app.ui.screens.events

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.nexory.app.navigation.Screen
import com.nexory.app.ui.theme.NexoryColors

@Composable
fun EventDetailScreen(
    navController: NavController,
    eventId: String,
    viewModel: EventDetailViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    LaunchedEffect(eventId) { viewModel.loadEvent(eventId) }

    Scaffold(containerColor = NexoryColors.DeepBlack) { padding ->
        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NexoryColors.PrimaryBlue)
            }
            return@Scaffold
        }

        val event = uiState.event ?: return@Scaffold

        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {

            // Обложка + кнопка назад
            item {
                Box(modifier = Modifier.fillMaxWidth().height(250.dp)) {
                    if (event.coverUrl != null) {
                        AsyncImage(
                            model = event.coverUrl, contentDescription = null,
                            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                        )
                        // Затемнение поверх обложки
                        Box(modifier = Modifier.fillMaxSize().background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, NexoryColors.DeepBlack)
                            )
                        ))
                    } else {
                        Box(modifier = Modifier.fillMaxSize().background(
                            Brush.linearGradient(listOf(NexoryColors.DeepBlue, NexoryColors.Violet))
                        ), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Event, null, tint = Color.White.copy(0.4f),
                                modifier = Modifier.size(80.dp))
                        }
                    }
                    IconButton(
                        onClick = { navController.popBackStack() },
                        modifier = Modifier.padding(12.dp)
                            .background(Color.Black.copy(0.4f), CircleShape),
                    ) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            }

            // Заголовок и мета
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    event.category?.let {
                        Text(it.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = NexoryColors.LightViolet)
                        Spacer(Modifier.height(4.dp))
                    }
                    Text(event.title, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                        color = NexoryColors.TextPrimary)

                    Spacer(Modifier.height(12.dp))

                    // Создатель
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = event.creatorAvatar,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp).clip(CircleShape)
                                .background(NexoryColors.SurfaceMid),
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Организатор", fontSize = 11.sp, color = NexoryColors.TextSecondary)
                            Text(event.creatorUsername, fontSize = 14.sp,
                                color = NexoryColors.PrimaryBlue, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Инфо-плашки
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InfoChip(icon = Icons.Default.CalendarToday, text = event.startsAt.take(10))
                        InfoChip(icon = Icons.Default.LocationOn, text = event.address)
                        val countText = if (event.maxParticipants != null)
                            "${event.participantCount}/${event.maxParticipants}"
                        else "${event.participantCount}"
                        InfoChip(icon = Icons.Default.People, text = countText)
                    }
                }
            }

            // Описание
            item {
                if (!event.description.isNullOrBlank()) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        HorizontalDivider(color = NexoryColors.SurfaceMid)
                        Spacer(Modifier.height(12.dp))
                        Text("Описание", fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            color = NexoryColors.TextPrimary)
                        Spacer(Modifier.height(8.dp))
                        Text(event.description, fontSize = 14.sp, color = NexoryColors.TextSecondary,
                            lineHeight = 22.sp)
                    }
                }
            }

            // Участники
            item {
                if (uiState.participants.isNotEmpty()) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text("Участники", fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            color = NexoryColors.TextPrimary)
                        Spacer(Modifier.height(10.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(uiState.participants) { participant ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    AsyncImage(
                                        model = participant.avatarUrl,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp).clip(CircleShape)
                                            .background(NexoryColors.SurfaceMid),
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(participant.username, fontSize = 11.sp,
                                        color = NexoryColors.TextSecondary, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }

            // Кнопка записи / отписки
            item {
                Spacer(Modifier.height(12.dp))
                val isJoined    = uiState.isJoined
                val isMyEvent   = uiState.isMyEvent
                val isFull      = event.maxParticipants != null &&
                        event.participantCount >= event.maxParticipants

                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    if (!isMyEvent) {
                        Button(
                            onClick  = { if (isJoined) viewModel.leaveEvent(eventId) else viewModel.joinEvent(eventId) },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            enabled  = !isFull || isJoined,
                            shape    = RoundedCornerShape(14.dp),
                            colors   = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues(0.dp),
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize().background(
                                    if (isJoined) Brush.linearGradient(listOf(NexoryColors.Error, NexoryColors.Error.copy(0.7f)))
                                    else Brush.linearGradient(listOf(NexoryColors.GradientStart, NexoryColors.GradientEnd))
                                ),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    text = when {
                                        isFull && !isJoined -> "Мест нет"
                                        isJoined -> "Отписаться"
                                        else -> "Записаться"
                                    },
                                    fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = Color.White
                                )
                            }
                        }
                    } else {
                        // Создатель видит кнопку открытия чата мероприятия
                        OutlinedButton(
                            onClick = { uiState.eventChatId?.let { navController.navigate(Screen.ChatDetail.route(it)) } },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoryColors.PrimaryBlue),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NexoryColors.PrimaryBlue),
                        ) {
                            Icon(Icons.Default.Chat, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Чат мероприятия", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun InfoChip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        modifier = Modifier
            .background(NexoryColors.SurfaceMid, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = NexoryColors.PrimaryBlue, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 12.sp, color = NexoryColors.TextPrimary, maxLines = 1)
    }
}