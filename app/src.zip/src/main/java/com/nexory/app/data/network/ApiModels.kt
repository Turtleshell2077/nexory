package com.nexory.app.data.network

import com.google.gson.annotations.SerializedName

// ---- Авторизация ----

// Ответ на /auth/login и /auth/register
data class AuthResponse(
    val user:         UserDto,
    @SerializedName("accessToken")  val accessToken:  String,
    @SerializedName("refreshToken") val refreshToken: String,
)

// Ответ на /auth/refresh
data class TokenResponse(
    @SerializedName("accessToken")  val accessToken:  String,
    @SerializedName("refreshToken") val refreshToken: String,
)

// ---- Пользователь ----

data class UserDto(
    val id:         String,
    val username:   String,
    val email:      String?     = null,
    val phone:      String?     = null,
    @SerializedName("avatar_url") val avatarUrl: String? = null,
    val bio:        String?     = null,
    val role:       String      = "user",
    @SerializedName("created_at") val createdAt: String? = null,
)

// Используется в списке друзей — сервер возвращает чуть меньше полей
typealias FriendDto = UserDto

// ---- Мероприятия ----

data class EventDto(
    val id:          String,
    val title:       String,
    val description: String?  = null,
    val address:     String,
    @SerializedName("cover_url")         val coverUrl:        String? = null,
    val category:    String?  = null,
    @SerializedName("starts_at")         val startsAt:        String,
    @SerializedName("ends_at")           val endsAt:          String? = null,
    @SerializedName("max_participants")  val maxParticipants: Int?    = null,
    @SerializedName("participant_count") val participantCount: Int    = 0,
    @SerializedName("is_private")        val isPrivate:       Boolean = false,
    val status:      String   = "active",
    // Создатель — denormalized для удобства UI
    @SerializedName("creator_id")       val creatorId:       String? = null,
    @SerializedName("creator_username") val creatorUsername:  String  = "",
    @SerializedName("creator_avatar")   val creatorAvatar:   String? = null,
)

// Ответ на GET /events (с пагинацией)
data class EventsPage(
    val events: List<EventDto>,
    val total:  Int,
    val page:   Int,
    val limit:  Int,
)

// ---- Чаты ----

data class ChatDto(
    val id:       String,
    val type:     String,         // "direct" | "event" | "support"
    @SerializedName("event_id")    val eventId:    String?       = null,
    val peer:                      PeerDto?        = null,   // для direct-чата
    @SerializedName("event_info")  val eventInfo:  EventInfoDto? = null, // для event-чата
    @SerializedName("last_message") val lastMessage: LastMessageDto? = null,
    @SerializedName("unread_count") val unreadCount: Int = 0,
    @SerializedName("last_read_at") val lastReadAt:  String? = null,
)

// Собеседник в direct-чате
data class PeerDto(
    val id:         String,
    val username:   String,
    @SerializedName("avatar_url") val avatarUrl: String? = null,
)

// Краткая инфо о мероприятии для чата
data class EventInfoDto(
    val id:    String,
    val title: String,
)

// Последнее сообщение в чате (для списка чатов)
data class LastMessageDto(
    val id:       String,
    val content:  String,
    @SerializedName("created_at")       val createdAt:       String,
    @SerializedName("sender_username")  val senderUsername:  String,
)

// ---- Сообщения ----

data class MessageDto(
    val id:       String,
    @SerializedName("chat_id")    val chatId:    String  = "",
    val content:  String,
    val type:     String  = "text",
    @SerializedName("is_deleted") val isDeleted: Boolean = false,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("sender_id")        val senderId:       String  = "",
    @SerializedName("sender_username")  val senderUsername:  String  = "",
    @SerializedName("sender_avatar")    val senderAvatar:    String? = null,
)

// Обёртка WebSocket-события "new_message"
data class WsNewMessagePayload(
    val message: MessageDto? = null,
)

// ---- Создание чата ----

data class CreateDirectChatResponse(
    @SerializedName("chatId") val chatId: String,
    @SerializedName("isNew")  val isNew:  Boolean,
)