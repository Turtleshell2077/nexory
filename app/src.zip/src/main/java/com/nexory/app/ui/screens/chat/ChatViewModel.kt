package com.nexory.app.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexory.app.data.local.TokenManager
import com.nexory.app.data.network.MessageDto
import com.nexory.app.data.network.NexoryApi
import com.nexory.app.data.websocket.ChatWebSocketManager
import com.nexory.app.data.websocket.WsEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatUiState(
    val messages:      List<MessageDto> = emptyList(),
    val chatTitle:     String           = "",
    val currentUserId: String           = "",
    val isLoading:     Boolean          = false,
    val oldestMessageId: String?        = null,   // для курсорной пагинации
    val hasMore:       Boolean          = true,
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val api:          NexoryApi,
    private val wsManager:    ChatWebSocketManager,
    private val tokenManager: TokenManager,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState = _uiState.asStateFlow()

    private var currentChatId: String = ""

    fun loadChat(chatId: String) {
        currentChatId = chatId
        viewModelScope.launch {
            val userId = tokenManager.getUserId() ?: ""
            _uiState.update { it.copy(currentUserId = userId, isLoading = true) }
            try {
                val response = api.getMessages(chatId)
                val messages = response["messages"] ?: emptyList()
                _uiState.update {
                    it.copy(
                        messages        = messages,
                        isLoading       = false,
                        oldestMessageId = messages.firstOrNull()?.id,
                        hasMore         = messages.size >= 30,
                    )
                }
                // Отмечаем сообщения как прочитанные
                wsManager.markRead(chatId)
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false) }
            }
        }

        // Подписываемся на входящие сообщения от WebSocket
        // collectLatest автоматически отменяется при уничтожении ViewModel
        viewModelScope.launch {
            wsManager.events.collect { event ->
                if (event is WsEvent.NewMessage) {
                    val msg = event.message.message ?: return@collect
                    if (msg.chatId == chatId) {
                        _uiState.update { state ->
                            // Не добавляем дубликаты (своё сообщение приходит и через WS)
                            if (state.messages.any { it.id == msg.id }) state
                            else state.copy(messages = state.messages + msg)
                        }
                        wsManager.markRead(chatId)
                    }
                }
            }
        }
    }

    // Загрузить более старые сообщения (прокрутка вверх)
    fun loadMoreMessages() {
        val state = _uiState.value
        if (state.isLoading || !state.hasMore) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val response = api.getMessages(
                    chatId = currentChatId,
                    before = state.oldestMessageId,
                )
                val older = response["messages"] ?: emptyList()
                _uiState.update {
                    it.copy(
                        messages        = older + it.messages,  // старые сверху
                        isLoading       = false,
                        oldestMessageId = older.firstOrNull()?.id ?: it.oldestMessageId,
                        hasMore         = older.size >= 30,
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun sendMessage(chatId: String, content: String) {
        // Оптимистичный UI: добавляем сообщение локально мгновенно,
        // не ждём подтверждения от сервера — это делает чат ощущаться быстрым
        val tempId = "temp_${System.currentTimeMillis()}"
        val tempMsg = MessageDto(
            id             = tempId,
            chatId         = chatId,
            content        = content,
            createdAt      = java.time.Instant.now().toString(),
            senderId       = _uiState.value.currentUserId,
            senderUsername = "Вы",
        )
        _uiState.update { it.copy(messages = it.messages + tempMsg) }

        // Отправляем через WebSocket
        wsManager.sendMessage(chatId, content)
    }
}