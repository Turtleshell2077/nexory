@Composable
fun ChatsScreen(navController: NavController, viewModel: ChatsListViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        containerColor = NexoryColors.DeepBlack,
        topBar = {
            TopAppBar(
                title = { Text("Чаты", color = NexoryColors.TextPrimary, fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoryColors.SurfaceDark),
            )
        },
        bottomBar = { NexoryBottomBar(navController, Screen.Chats.route) }
    ) { padding ->
        if (state.chats.isEmpty() && !state.isLoading) {
            EmptyState(Icons.Default.ChatBubbleOutline, "Нет чатов")
            return@Scaffold
        }
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(vertical = 8.dp)) {
            items(state.chats, key = { it.id }) { chat ->
                ChatListItem(chat = chat, onClick = {
                    navController.navigate(Screen.ChatDetail.route(chat.id))
                })
            }
        }
    }
}

@Composable
fun ChatListItem(chat: com.nexory.app.data.network.ChatDto, onClick: () -> Unit) {
    val title = when (chat.type) {
        "direct" -> chat.peer?.username ?: "Чат"
        "event"  -> chat.eventInfo?.title ?: "Чат мероприятия"
        "support" -> "Поддержка"
        else -> "Чат"
    }
    val subtitle = chat.lastMessage?.content ?: "Нет сообщений"
    val time     = chat.lastMessage?.createdAt?.substring(11, 16) ?: ""

    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Аватар / иконка
        Box(
            modifier = Modifier.size(52.dp).clip(CircleShape).background(
                Brush.linearGradient(listOf(NexoryColors.DeepBlue.copy(0.6f), NexoryColors.Violet.copy(0.6f)))
            ),
            contentAlignment = Alignment.Center,
        ) {
            val peer = chat.peer
            if (peer?.avatarUrl != null) {
                AsyncImage(model = peer.avatarUrl, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape))
            } else {
                Icon(
                    when (chat.type) { "event" -> Icons.Default.Event; "support" -> Icons.Default.Support; else -> Icons.Default.Person },
                    null, tint = Color.White, modifier = Modifier.size(24.dp)
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, fontWeight = FontWeight.SemiBold, color = NexoryColors.TextPrimary, fontSize = 15.sp)
                Text(time, fontSize = 12.sp, color = NexoryColors.TextSecondary)
            }
            Spacer(Modifier.height(2.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(subtitle, fontSize = 13.sp, color = NexoryColors.TextSecondary, maxLines = 1, modifier = Modifier.weight(1f))
                if (chat.unreadCount > 0) {
                    Box(modifier = Modifier.size(20.dp).background(NexoryColors.PrimaryBlue, CircleShape), contentAlignment = Alignment.Center) {
                        Text("${chat.unreadCount}", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    HorizontalDivider(modifier = Modifier.padding(start = 80.dp), color = NexoryColors.SurfaceMid, thickness = 0.5.dp)
}