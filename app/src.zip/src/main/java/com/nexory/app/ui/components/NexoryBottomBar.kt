@Composable
fun NexoryBottomBar(navController: NavController, currentRoute: String) {
    NavigationBar(
        containerColor = NexoryColors.SurfaceDark,
        tonalElevation = 0.dp,
    ) {
        val items = listOf(
            Triple(Screen.Feed.route,    Icons.Default.Home,    "Лента"),
            Triple(Screen.Chats.route,   Icons.Default.Chat,    "Чаты"),
            Triple(Screen.Friends.route, Icons.Default.People,  "Друзья"),
            Triple(Screen.Profile.route, Icons.Default.Person,  "Профиль"),
        )

        items.forEach { (route, icon, label) ->
            val selected = currentRoute == route
            NavigationBarItem(
                selected = selected,
                onClick  = {
                    if (!selected) navController.navigate(route) {
                        // Чистим back stack — не копим экраны при клике на таб
                        popUpTo(Screen.Feed.route) { saveState = true }
                        launchSingleTop = true
                        restoreState    = true
                    }
                },
                icon  = {
                    Icon(icon, contentDescription = label,
                        tint = if (selected) NexoryColors.PrimaryBlue else NexoryColors.TextSecondary)
                },
                label = {
                    Text(label, fontSize = 11.sp,
                        color = if (selected) NexoryColors.PrimaryBlue else NexoryColors.TextSecondary)
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = NexoryColors.DeepBlue.copy(alpha = 0.2f),
                ),
            )
        }
    }
}