package com.nexory.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.rememberNavController
import com.nexory.app.data.local.TokenManager
import com.nexory.app.navigation.AppNavHost
import com.nexory.app.ui.theme.NexoryTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.map
import javax.inject.Inject

@AndroidEntryPoint   // Hilt: Activity может принимать инжекции
class MainActivity : ComponentActivity() {

    @Inject lateinit var tokenManager: TokenManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()  // контент под system bars

        setContent {
            NexoryTheme {
                // Реактивно следим за состоянием авторизации.
                // collectAsState() автоматически перерисует NavHost при изменении.
                val isLoggedIn by tokenManager.isLoggedIn()
                    .collectAsState(initial = false)

                val navController = rememberNavController()

                AppNavHost(
                    navController = navController,
                    isLoggedIn    = isLoggedIn,
                )
            }
        }
    }
}