package com.nexory.app.ui.screens.support

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.nexory.app.ui.components.NexoryField
import com.nexory.app.ui.components.nexoryTextFieldColors
import com.nexory.app.ui.theme.NexoryColors

@Composable
fun SupportScreen(
    navController: NavController,
    viewModel: SupportViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    var subject by remember { mutableStateOf("") }
    var body    by remember { mutableStateOf("") }

    LaunchedEffect(state.isSent) {
        if (state.isSent) navController.popBackStack()
    }

    Scaffold(
        containerColor = NexoryColors.DeepBlack,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Поддержка",
                        color      = NexoryColors.TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = NexoryColors.TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NexoryColors.SurfaceDark
                ),
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                "Опиши свою проблему — мы ответим на email",
                fontSize = 14.sp,
                color    = NexoryColors.TextSecondary,
            )

            NexoryField(
                value         = subject,
                onValueChange = { subject = it },
                label         = "Тема *",
                icon          = Icons.Default.Subject,
            )

            OutlinedTextField(
                value         = body,
                onValueChange = { body = it },
                modifier      = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                label         = { Text("Сообщение *") },
                leadingIcon   = { Icon(Icons.Default.Message, null) },
                maxLines      = 10,
                shape         = RoundedCornerShape(12.dp),
                colors        = nexoryTextFieldColors(),
            )

            state.error?.let {
                Text(it, color = NexoryColors.Error, fontSize = 13.sp)
            }

            Button(
                onClick  = { viewModel.send(subject, body) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                enabled  = subject.isNotBlank() && body.isNotBlank() && !state.isLoading,
                shape    = RoundedCornerShape(14.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues(0.dp),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(NexoryColors.GradientStart, NexoryColors.GradientEnd)
                            )
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (state.isLoading) {
                        CircularProgressIndicator(
                            color     = Color.White,
                            modifier  = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Send, null, tint = Color.White)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Отправить",
                                fontWeight = FontWeight.SemiBold,
                                color      = Color.White,
                            )
                        }
                    }
                }
            }
        }
    }
}