package com.nexory.app.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexory.app.data.network.NexoryApi
import com.nexory.app.data.network.UserDto
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditProfileUiState(
    val user:      UserDto? = null,
    val isLoading: Boolean  = false,
    val isSaved:   Boolean  = false,
    val error:     String?  = null,
)

@HiltViewModel
class EditProfileViewModel @Inject constructor(
    private val api: NexoryApi,
) : ViewModel() {

    private val _state = MutableStateFlow(EditProfileUiState())
    val state = _state.asStateFlow()

    init { loadProfile() }

    private fun loadProfile() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val response = api.getMyProfile()
                _state.update { it.copy(user = response["user"], isLoading = false) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    fun save(username: String, bio: String, avatarUrl: String) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            try {
                val body = mapOf(
                    "username"   to username.takeIf { it.isNotBlank() },
                    "bio"        to bio.takeIf { it.isNotBlank() },
                    "avatar_url" to avatarUrl.takeIf { it.isNotBlank() },
                )
                val response = api.updateProfile(body)
                _state.update { it.copy(
                    user      = response["user"],
                    isLoading = false,
                    isSaved   = true,
                )}
            } catch (e: Exception) {
                val message = if (e.message?.contains("409") == true)
                    "Имя пользователя уже занято"
                else "Ошибка сохранения: ${e.message}"
                _state.update { it.copy(isLoading = false, error = message) }
            }
        }
    }
}