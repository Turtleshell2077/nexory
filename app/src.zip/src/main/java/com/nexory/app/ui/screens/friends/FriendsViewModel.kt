package com.nexory.app.ui.screens.friends

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.nexory.app.data.network.FriendDto
import com.nexory.app.data.network.NexoryApi
import com.nexory.app.navigation.Screen
import com.nexory.app.ui.theme.NexoryColors
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FriendsUiState(
    val friends:    List<FriendDto> = emptyList(),
    val requests:   List<FriendDto> = emptyList(),
    val searchResults: List<FriendDto> = emptyList(),
    val searchQuery: String = "",
    val tab:        Int     = 0,   // 0=друзья, 1=запросы, 2=поиск
    val isLoading:  Boolean = false,
)

@HiltViewModel
class FriendsViewModel @Inject constructor(private val api: NexoryApi) : ViewModel() {
    private val _state = MutableStateFlow(FriendsUiState())
    val state = _state.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val friends  = api.getFriends()["friends"]  ?: emptyList()
                val requests = api.getFriendRequests()["requests"] ?: emptyList()
                _state.update { it.copy(friends = friends, requests = requests, isLoading = false) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false) }
            }
        }
    }

    fun search(query: String) {
        _state.update { it.copy(searchQuery = query) }
        if (query.length < 2) { _state.update { it.copy(searchResults = emptyList()) }; return }
        viewModelScope.launch {
            try {
                val results = api.searchUsers(query)["users"] ?: emptyList()
                _state.update { it.copy(searchResults = results) }
            } catch (_: Exception) {}
        }
    }

    fun sendRequest(userId: String) {
        viewModelScope.launch {
            try { api.sendFriendRequest(mapOf("addresseeId" to userId)) } catch (_: Exception) {}
        }
    }

    fun acceptRequest(requesterId: String) {
        viewModelScope.launch {
            try {
                api.acceptFriendRequest(mapOf("requesterId" to requesterId))
                load()
            } catch (_: Exception) {}
        }
    }

    fun removeFriend(friendId: String) {
        viewModelScope.launch {
            try { api.removeFriend(friendId); load() } catch (_: Exception) {}
        }
    }

    fun setTab(tab: Int) = _state.update { it.copy(tab = tab) }
}