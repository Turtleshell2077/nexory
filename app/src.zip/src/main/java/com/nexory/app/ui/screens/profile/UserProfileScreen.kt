package com.nexory.app.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.nexory.app.data.network.EventDto
import com.nexory.app.data.network.NexoryApi
import com.nexory.app.data.network.UserDto
import com.nexory.app.navigation.Screen
import com.nexory.app.ui.theme.NexoryColors
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ---- ViewModel ----

data class UserProfileUiState(
    val user:      UserDto?       = null,
    val events:    List<EventDto> = emptyList(),
    val isFriend:  Boolean        = false,
    val isLoading: Boolean        = false,
)

@HiltViewModel
class UserProfileViewModel @Inject constructor(
    private val api: NexoryApi,
) : ViewModel() {

    private val _state = MutableStateFlow(UserProfileUiState())
    val state = _state.asStateFlow()

    fun load(userId: String) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val response = api.getUserProfile(userId)
                val userMap  = response["user"] as? Map<*, *>
                val user = userMap?.let {
                    UserDto(
                        id        = it["id"] as? String ?: "",
                        username  = it["username"] as? String ?: "",
                        avatarUrl = it["avatar_url"] as? String,
                        bio       = it["bio"] as? String,
                    )
                }
                _state.update { it.copy(user = user, isLoading = false) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false) }
            }
        }
    }

    fun sendFriendRequest(userId: String) {
        viewModelScope.launch {
            try {
                api.sendFriendRequest(mapOf("addresseeId" to userId))
            } catch (_: Exception) {}
        }
    }

    fun openDirectChat(userId: String, onChatReady: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val response = api.getOrCreateDirectChat(mapOf("peerId" to userId))
                onChatReady(response.chatId)
            } catch (_: Exception) {}
        }
    }
}

// ---- UI ----

@Composable
fun UserProfileScreen(
    navController: NavController,
    userId:        String,
    viewModel:     UserProfileViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    LaunchedEffect(userId) { viewModel.load(userId) }

    Scaffold(
        containerColor = NexoryColors.DeepBlack,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text       = state.user?.username ?: "Профиль",
                        color      = NexoryColors.TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = NexoryColors.TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NexoryColors.SurfaceDark
                ),
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(24.dp))

            // Аватар
            AsyncImage(
                model              = state.user?.avatarUrl,
                contentDescription = null,
                modifier           = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(NexoryColors.SurfaceMid),
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text       = state.user?.username ?: "...",
                fontSize   = 22.sp,
                fontWeight = FontWeight.Bold,
                color      = NexoryColors.TextPrimary,
            )

            state.user?.bio?.let {
                Text(
                    text     = it,
                    fontSize = 13.sp,
                    color    = NexoryColors.TextSecondary,
                    modifier = Modifier.padding(top = 6.dp, start = 32.dp, end = 32.dp),
                )
            }

            Spacer(Modifier.height(24.dp))

            // Кнопки действий
            Row(
                modifier              = Modifier.padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Button(
                    onClick = {
                        viewModel.openDirectChat(userId) { chatId ->
                            navController.navigate(Screen.ChatDetail.route(chatId))
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = ButtonDefaults.buttonColors(
                        containerColor = NexoryColors.PrimaryBlue
                    ),
                ) {
                    Icon(Icons.Default.Chat, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Написать")
                }

                OutlinedButton(
                    onClick  = { viewModel.sendFriendRequest(userId) },
                    modifier = Modifier.weight(1f),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = ButtonDefaults.outlinedButtonColors(
                        contentColor = NexoryColors.PrimaryBlue
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp, NexoryColors.PrimaryBlue
                    ),
                ) {
                    Icon(Icons.Default.PersonAdd, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Добавить")
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}