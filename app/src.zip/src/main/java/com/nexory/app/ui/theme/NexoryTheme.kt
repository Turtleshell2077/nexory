package com.nexory.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ---- Палитра ----
object NexoryColors {
    val DeepBlack    = Color(0xFF0A0A12)
    val SurfaceDark  = Color(0xFF12121F)
    val SurfaceMid   = Color(0xFF1E1E30)

    val PrimaryBlue  = Color(0xFF4A90E2)
    val DeepBlue     = Color(0xFF1A3A6B)
    val Violet       = Color(0xFF7B4FE0)
    val LightViolet  = Color(0xFFAA80FF)

    val GradientStart = Color(0xFF4A90E2)
    val GradientEnd   = Color(0xFF7B4FE0)

    val TextPrimary   = Color(0xFFF0F0F8)
    val TextSecondary = Color(0xFF8888AA)

    val Error = Color(0xFFE25A5A)
}

// ---- Material3 тёмная схема ----
private val NexoryColorScheme = darkColorScheme(
    primary          = NexoryColors.PrimaryBlue,
    secondary        = NexoryColors.Violet,
    tertiary         = NexoryColors.LightViolet,
    background       = NexoryColors.DeepBlack,
    surface          = NexoryColors.SurfaceDark,
    surfaceVariant   = NexoryColors.SurfaceMid,
    onPrimary        = Color.White,
    onSecondary      = Color.White,
    onBackground     = NexoryColors.TextPrimary,
    onSurface        = NexoryColors.TextPrimary,
    error            = NexoryColors.Error,
)

@Composable
fun NexoryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexoryColorScheme,
        typography  = NexoryTypography,
        content     = content,
    )
}

// ---- Цвета полей ввода ----
@Composable
fun nexoryTextFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedBorderColor        = NexoryColors.PrimaryBlue,
    unfocusedBorderColor      = NexoryColors.SurfaceMid,
    focusedContainerColor     = NexoryColors.SurfaceMid,
    unfocusedContainerColor   = NexoryColors.SurfaceMid,
    cursorColor               = NexoryColors.PrimaryBlue,
    focusedTextColor          = NexoryColors.TextPrimary,
    unfocusedTextColor        = NexoryColors.TextPrimary,
    focusedLabelColor         = NexoryColors.PrimaryBlue,
    unfocusedLabelColor       = NexoryColors.TextSecondary,
    focusedLeadingIconColor   = NexoryColors.PrimaryBlue,
    unfocusedLeadingIconColor = NexoryColors.TextSecondary,
)