data class ChatsListUiState(val chats: List<com.nexory.app.data.network.ChatDto> = emptyList(), val isLoading: Boolean = false)

@HiltViewModel
class ChatsListViewModel @Inject constructor(private val api: NexoryApi) : ViewModel() {
    private val _state = MutableStateFlow(ChatsListUiState())
    val state = _state.asStateFlow()
    init {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val chats = api.getChats()["chats"] ?: emptyList()
                _state.update { it.copy(chats = chats, isLoading = false) }
            } catch (_: Exception) { _state.update { it.copy(isLoading = false) } }
        }
    }
}