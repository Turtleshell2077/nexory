package com.nexory.app.ui.screens.feed

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.nexory.app.data.network.EventDto
import com.nexory.app.navigation.Screen
import com.nexory.app.ui.theme.NexoryColors

@Composable
fun FeedScreen(
    navController: NavController,
    viewModel: FeedViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()

    // Инфинит скролл: когда видим предпоследний элемент — грузим следующую страницу
    LaunchedEffect(listState.firstVisibleItemIndex) {
        val lastIndex  = uiState.events.size - 1
        val visible    = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
        if (visible >= lastIndex - 2 && !uiState.isLoading) {
            viewModel.loadEvents()
        }
    }

    Scaffold(
        containerColor = NexoryColors.DeepBlack,
        floatingActionButton = {
            // Кнопка добавления нового мероприятия
            FloatingActionButton(
                onClick = { navController.navigate(Screen.CreateEvent.route) },
                containerColor = Color.Transparent,
                modifier = Modifier.background(
                    brush = Brush.linearGradient(
                        listOf(NexoryColors.GradientStart, NexoryColors.GradientEnd)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
            ) {
                Icon(Icons.Default.Add, contentDescription = "Добавить мероприятие",
                    tint = Color.White)
            }
        },
        bottomBar = { NexoryBottomBar(navController, currentRoute = Screen.Feed.route) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Поисковая строка
            SearchBar(
                query    = uiState.searchQuery,
                onSearch = viewModel::search,
            )

            // Переключатель "Все" / "Мои"
            FeedToggle(
                isMyEvents = uiState.isMyEvents,
                onToggle   = viewModel::toggleFeedMode,
            )

            LazyColumn(
                state            = listState,
                contentPadding   = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(uiState.events, key = { it.id }) { event ->
                    EventCard(
                        event    = event,
                        onClick  = { navController.navigate(Screen.EventDetail.route(event.id)) }
                    )
                }
                if (uiState.isLoading) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(16.dp),
                            contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = NexoryColors.PrimaryBlue)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchBar(query: String, onSearch: (String) -> Unit) {
    var text by remember { mutableStateOf(query) }

    OutlinedTextField(
        value = text,
        onValueChange = {
            text = it
            onSearch(it)
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("Поиск мероприятий...", color = NexoryColors.TextSecondary) },
        leadingIcon  = { Icon(Icons.Default.Search, null, tint = NexoryColors.TextSecondary) },
        trailingIcon = if (text.isNotEmpty()) {{
            IconButton(onClick = { text = ""; onSearch("") }) {
                Icon(Icons.Default.Clear, null, tint = NexoryColors.TextSecondary)
            }
        }} else null,
        singleLine   = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor   = NexoryColors.PrimaryBlue,
            unfocusedBorderColor = NexoryColors.SurfaceMid,
            focusedContainerColor   = NexoryColors.SurfaceMid,
            unfocusedContainerColor = NexoryColors.SurfaceMid,
            cursorColor = NexoryColors.PrimaryBlue,
            focusedTextColor    = NexoryColors.TextPrimary,
            unfocusedTextColor  = NexoryColors.TextPrimary,
        )
    )
}

@Composable
fun FeedToggle(isMyEvents: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(NexoryColors.SurfaceDark),
    ) {
        listOf("Все мероприятия" to false, "Мои записи" to true).forEach { (label, isMyTab) ->
            val selected = isMyEvents == isMyTab
            val bgColor by animateColorAsState(
                if (selected) NexoryColors.DeepBlue else Color.Transparent, label = "tabBg"
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bgColor)
                    .clickable(onClick = { if (!selected) onToggle() })
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text  = label,
                    color = if (selected) Color.White else NexoryColors.TextSecondary,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    fontSize = 14.sp,
                )
            }
        }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun EventCard(event: EventDto, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = NexoryColors.SurfaceDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
    ) {
        Column {
            // Обложка мероприятия
            if (event.coverUrl != null) {
                AsyncImage(
                    model             = event.coverUrl,
                    contentDescription = event.title,
                    modifier          = Modifier.fillMaxWidth().height(160.dp),
                    contentScale      = ContentScale.Crop,
                )
            } else {
                // Градиентный placeholder если нет обложки
                Box(
                    modifier = Modifier.fillMaxWidth().height(100.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(NexoryColors.DeepBlue.copy(alpha = 0.6f),
                                    NexoryColors.Violet.copy(alpha = 0.4f))
                            )
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.Event, null,
                        tint = Color.White.copy(alpha = 0.5f), modifier = Modifier.size(48.dp))
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                // Категория (если есть)
                event.category?.let { cat ->
                    Text(cat.uppercase(), fontSize = 11.sp,
                        color = NexoryColors.LightViolet, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp))
                }

                Text(event.title, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                    color = NexoryColors.TextPrimary)

                Spacer(Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null,
                        tint = NexoryColors.TextSecondary, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(event.address, fontSize = 13.sp, color = NexoryColors.TextSecondary,
                        maxLines = 1)
                }

                Spacer(Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarToday, null,
                            tint = NexoryColors.PrimaryBlue, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(event.startsAt.take(10), fontSize = 12.sp,
                            color = NexoryColors.PrimaryBlue)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.People, null,
                            tint = NexoryColors.TextSecondary, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        val participantText = if (event.maxParticipants != null)
                            "${event.participantCount}/${event.maxParticipants}"
                        else "${event.participantCount}"
                        Text(participantText, fontSize = 12.sp,
                            color = NexoryColors.TextSecondary)
                    }
                }
            }
        }
    }
}