data class CreateEventUiState(val isLoading: Boolean = false, val isCreated: Boolean = false, val error: String? = null)

@HiltViewModel
class CreateEventViewModel @Inject constructor(private val api: NexoryApi) : ViewModel() {
    private val _state = MutableStateFlow(CreateEventUiState())
    val uiState = _state.asStateFlow()

    fun createEvent(title: String, description: String?, address: String, category: String?,
                    startsAt: String, maxParticipants: Int?, isPrivate: Boolean) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            try {
                val body = buildMap<String, String?> {
                    put("title", title)
                    put("address", address)
                    put("starts_at", startsAt)
                    if (description != null) put("description", description)
                    if (category != null) put("category", category)
                    if (maxParticipants != null) put("max_participants", maxParticipants.toString())
                    put("is_private", isPrivate.toString())
                }
                api.createEvent(body)
                _state.update { it.copy(isLoading = false, isCreated = true) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = "Ошибка: ${e.message}") }
            }
        }
    }
}