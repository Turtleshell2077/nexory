package com.nexory.app.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.nexory.app.ui.components.NexoryField
import com.nexory.app.ui.theme.NexoryColors

@Composable
fun EditProfileScreen(
    navController: NavController,
    viewModel: EditProfileViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.isSaved) {
        if (state.isSaved) navController.popBackStack()
    }

    var username  by remember(state.user) { mutableStateOf(state.user?.username ?: "") }
    var bio       by remember(state.user) { mutableStateOf(state.user?.bio ?: "") }
    var avatarUrl by remember(state.user) { mutableStateOf(state.user?.avatarUrl ?: "") }

    Scaffold(
        containerColor = NexoryColors.DeepBlack,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Редактировать профиль",
                        color      = NexoryColors.TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = NexoryColors.TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NexoryColors.SurfaceDark
                ),
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Аватар
            Box(contentAlignment = Alignment.BottomEnd) {
                AsyncImage(
                    model              = avatarUrl.ifBlank { null },
                    contentDescription = null,
                    modifier           = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(NexoryColors.SurfaceMid),
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(NexoryColors.PrimaryBlue, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Default.Edit,
                        null,
                        tint     = Color.White,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }

            // Поля
            NexoryField(
                value         = username,
                onValueChange = { username = it },
                label         = "Имя пользователя",
                icon          = Icons.Default.Person,
            )

            NexoryField(
                value         = bio,
                onValueChange = { bio = it },
                label         = "О себе",
                icon          = Icons.Default.Info,
                maxLines      = 4,
            )

            NexoryField(
                value         = avatarUrl,
                onValueChange = { avatarUrl = it },
                label         = "Ссылка на аватар (URL)",
                icon          = Icons.Default.Image,
            )

            state.error?.let {
                Text(it, color = NexoryColors.Error, fontSize = 13.sp)
            }

            Spacer(Modifier.height(8.dp))

            Button(
                onClick        = { viewModel.save(username, bio, avatarUrl) },
                modifier       = Modifier.fillMaxWidth().height(52.dp),
                enabled        = !state.isLoading,
                shape          = RoundedCornerShape(14.dp),
                colors         = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues(0.dp),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(NexoryColors.GradientStart, NexoryColors.GradientEnd)
                            )
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (state.isLoading) {
                        CircularProgressIndicator(
                            color       = Color.White,
                            modifier    = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                        )
                    } else {
                        Text(
                            "Сохранить",
                            fontWeight = FontWeight.SemiBold,
                            fontSize   = 16.sp,
                            color      = Color.White,
                        )
                    }
                }
            }
        }
    }
}