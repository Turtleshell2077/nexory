package com.nexory.app.navigation

import androidx.compose.runtime.*
import androidx.navigation.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nexory.app.ui.screens.auth.LoginScreen
import com.nexory.app.ui.screens.auth.RegisterScreen
import com.nexory.app.ui.screens.chat.ChatDetailScreen
import com.nexory.app.ui.screens.chat.ChatsScreen
import com.nexory.app.ui.screens.events.CreateEventScreen
import com.nexory.app.ui.screens.events.EventDetailScreen
import com.nexory.app.ui.screens.feed.FeedScreen
import com.nexory.app.ui.screens.friends.FriendsScreen
import com.nexory.app.ui.screens.profile.ProfileScreen
import com.nexory.app.ui.screens.profile.UserProfileScreen
import com.nexory.app.ui.screens.support.SupportScreen

// ---- Маршруты ----
// sealed class гарантирует: все маршруты описаны явно,
// компилятор поймает опечатку в route-строке.
sealed class Screen(val route: String) {
    object Login     : Screen("login")
    object Register  : Screen("register")
    object Feed      : Screen("feed")
    object Chats     : Screen("chats")
    object Friends   : Screen("friends")
    object Profile   : Screen("profile")
    object Support   : Screen("support")
    object CreateEvent : Screen("create_event")

    // Маршруты с аргументами
    object EventDetail : Screen("event/{eventId}") {
        fun route(id: String) = "event/$id"
    }
    object ChatDetail : Screen("chat/{chatId}") {
        fun route(id: String) = "chat/$id"
    }
    object UserProfile : Screen("user/{userId}") {
        fun route(id: String) = "user/$id"
    }
}

@Composable
fun AppNavHost(
    navController: NavHostController,
    isLoggedIn: Boolean,
) {
    // Стартовый экран зависит от состояния авторизации
    val startDestination = if (isLoggedIn) Screen.Feed.route else Screen.Login.route

    NavHost(
        navController    = navController,
        startDestination = startDestination,
    ) {

        // ---- Auth ----
        composable(Screen.Login.route) {
            LoginScreen(navController = navController)
        }
        composable(Screen.Register.route) {
            RegisterScreen(navController = navController)
        }

        // ---- Main tabs ----
        composable(Screen.Feed.route) {
            FeedScreen(navController = navController)
        }
        composable(Screen.Chats.route) {
            ChatsScreen(navController = navController)
        }
        composable(Screen.Friends.route) {
            FriendsScreen(navController = navController)
        }
        composable(Screen.Profile.route) {
            ProfileScreen(navController = navController)
        }

        // ---- Детальные экраны ----
        composable(
            route     = Screen.EventDetail.route,
            arguments = listOf(navArgument("eventId") { type = NavType.StringType })
        ) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: return@composable
            EventDetailScreen(navController = navController, eventId = eventId)
        }

        composable(
            route     = Screen.ChatDetail.route,
            arguments = listOf(navArgument("chatId") { type = NavType.StringType })
        ) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getString("chatId") ?: return@composable
            ChatDetailScreen(navController = navController, chatId = chatId)
        }

        composable(
            route     = Screen.UserProfile.route,
            arguments = listOf(navArgument("userId") { type = NavType.StringType })
        ) { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: return@composable
            UserProfileScreen(navController = navController, userId = userId)
        }

        // ---- Прочие ----
        composable(Screen.CreateEvent.route) {
            CreateEventScreen(navController = navController)
        }
        composable(Screen.Support.route) {
            SupportScreen(navController = navController)
        }
    }
}