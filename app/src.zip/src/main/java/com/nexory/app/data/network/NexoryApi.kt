package com.nexory.app.data.network

import retrofit2.http.*

interface NexoryApi {

    // ---- Auth ----

    @POST("auth/register")
    suspend fun register(@Body body: Map<String, String>): AuthResponse

    @POST("auth/login")
    suspend fun login(@Body body: Map<String, String>): AuthResponse

    // Обновить пару токенов — вызывается из AuthInterceptor при 401
    @POST("auth/refresh")
    suspend fun refreshTokens(@Body body: Map<String, String>): TokenResponse

    @POST("auth/logout")
    suspend fun logout(@Body body: Map<String, String>): Map<String, String>

    // ---- Events ----

    @GET("events")
    suspend fun getEvents(
        @Query("page")     page:     Int    = 1,
        @Query("limit")    limit:    Int    = 20,
        @Query("category") category: String? = null,
        @Query("search")   search:   String? = null,
    ): EventsPage

    // Мероприятия, на которые записан пользователь
    @GET("events/my")
    suspend fun getMyEvents(): Map<String, List<EventDto>>

    @GET("events/{id}")
    suspend fun getEvent(@Path("id") id: String): Map<String, EventDto>

    @POST("events")
    suspend fun createEvent(@Body body: Map<String, String?>): Map<String, EventDto>

    @POST("events/{id}/join")
    suspend fun joinEvent(@Path("id") id: String): Map<String, String>

    @DELETE("events/{id}/leave")
    suspend fun leaveEvent(@Path("id") id: String): Map<String, String>

    @DELETE("events/{id}")
    suspend fun deleteEvent(@Path("id") id: String): Map<String, String>

    // ---- Chats ----

    // Все чаты пользователя (список с last_message и unread_count)
    @GET("chats")
    suspend fun getChats(): Map<String, List<ChatDto>>

    // История сообщений — курсорная пагинация по UUID сообщения
    @GET("chats/{id}/messages")
    suspend fun getMessages(
        @Path("id")    chatId: String,
        @Query("before") before: String? = null,
        @Query("limit")  limit:  Int     = 30,
    ): Map<String, List<MessageDto>>

    // Создать или получить уже существующий direct-чат
    @POST("chats/direct")
    suspend fun getOrCreateDirectChat(@Body body: Map<String, String>): CreateDirectChatResponse

    // ---- Friends ----

    @GET("friends")
    suspend fun getFriends(): Map<String, List<FriendDto>>

    @GET("friends/requests")
    suspend fun getFriendRequests(): Map<String, List<FriendDto>>

    @POST("friends/request")
    suspend fun sendFriendRequest(@Body body: Map<String, String>): Map<String, String>

    @POST("friends/accept")
    suspend fun acceptFriendRequest(@Body body: Map<String, String>): Map<String, String>

    @DELETE("friends/{id}")
    suspend fun removeFriend(@Path("id") friendId: String): Map<String, String>

    // ---- Users ----

    @GET("users/me")
    suspend fun getMyProfile(): Map<String, UserDto>

    @GET("users/{id}")
    suspend fun getUserProfile(@Path("id") userId: String): Map<String, Any>

    @PUT("users/me")
    suspend fun updateProfile(@Body body: Map<String, String?>): Map<String, UserDto>

    @PUT("users/me/password")
    suspend fun changePassword(@Body body: Map<String, String>): Map<String, String>

    // Обновить FCM-токен — вызывается при получении нового токена из Firebase
    @PUT("users/me/fcm-token")
    suspend fun updateFcmToken(@Body body: Map<String, String>): Map<String, String>

    @GET("users/search")
    suspend fun searchUsers(@Query("q") query: String): Map<String, List<FriendDto>>

    // ---- Support ----

    @POST("support")
    suspend fun createSupportTicket(@Body body: Map<String, String>): Map<String, String>
}