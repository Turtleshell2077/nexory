package com.nexory.app.ui.screens.feed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexory.app.data.network.EventDto
import com.nexory.app.data.network.NexoryApi
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FeedUiState(
    val events:      List<EventDto> = emptyList(),
    val isLoading:   Boolean        = false,
    val isMyEvents:  Boolean        = false,  // переключатель лента / мои
    val searchQuery: String         = "",
    val error:       String?        = null,
    val page:        Int            = 1,
    val hasMore:     Boolean        = true,
)

@HiltViewModel
class FeedViewModel @Inject constructor(
    private val api: NexoryApi,
) : ViewModel() {

    private val _uiState = MutableStateFlow(FeedUiState())
    val uiState = _uiState.asStateFlow()

    init { loadEvents(reset = true) }

    fun loadEvents(reset: Boolean = false) {
        val state = _uiState.value
        if (state.isLoading || (!reset && !state.hasMore)) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val page = if (reset) 1 else state.page

                val events = if (state.isMyEvents) {
                    api.getMyEvents()["events"] ?: emptyList()
                } else {
                    val response = api.getEvents(
                        page   = page,
                        search = state.searchQuery.takeIf { it.isNotBlank() },
                    )
                    if (reset) {
                        _uiState.update { it.copy(
                            hasMore = response.events.size == response.limit
                        )}
                    }
                    response.events
                }

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        events    = if (reset) events else it.events + events,
                        page      = if (reset) 2 else it.page + 1,
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    fun toggleFeedMode() {
        _uiState.update { it.copy(isMyEvents = !it.isMyEvents) }
        loadEvents(reset = true)
    }

    fun search(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        loadEvents(reset = true)
    }
}