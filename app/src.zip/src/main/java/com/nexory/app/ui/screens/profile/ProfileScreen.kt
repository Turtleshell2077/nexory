package com.nexory.app.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.nexory.app.navigation.Screen
import com.nexory.app.ui.screens.feed.NexoryBottomBar
import com.nexory.app.ui.theme.NexoryColors

@Composable
fun ProfileScreen(
    navController: NavController,
    viewModel: ProfileViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    var showEditDialog   by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.user) {
        if (uiState.user == null && !uiState.isLoading) {
            navController.navigate(Screen.Login.route) {
                popUpTo(0) { inclusive = true }
            }
        }
    }

    Scaffold(
        containerColor = NexoryColors.DeepBlack,
        bottomBar      = { NexoryBottomBar(navController, Screen.Profile.route) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
        ) {
            // Шапка с градиентом
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(NexoryColors.DeepBlue, NexoryColors.DeepBlack)
                        )
                    ),
                contentAlignment = Alignment.BottomCenter,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(bottom = 16.dp),
                ) {
                    AsyncImage(
                        model              = uiState.user?.avatarUrl,
                        contentDescription = "Аватар",
                        modifier           = Modifier
                            .size(84.dp)
                            .clip(CircleShape)
                            .background(NexoryColors.SurfaceMid),
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text       = uiState.user?.username ?: "...",
                        fontSize   = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color      = NexoryColors.TextPrimary,
                    )
                    uiState.user?.bio?.let {
                        Text(
                            text     = it,
                            fontSize = 13.sp,
                            color    = NexoryColors.TextSecondary,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Column(
                modifier            = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProfileMenuItem(
                    icon    = Icons.Default.Edit,
                    label   = "Редактировать профиль",
                    color   = NexoryColors.PrimaryBlue,
                    onClick = { showEditDialog = true },
                )
                ProfileMenuItem(
                    icon    = Icons.Default.Support,
                    label   = "Поддержка",
                    color   = NexoryColors.Violet,
                    onClick = { navController.navigate(Screen.Support.route) },
                )
                ProfileMenuItem(
                    icon    = Icons.Default.Lock,
                    label   = "Сменить пароль",
                    color   = NexoryColors.LightViolet,
                    onClick = { },
                )
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = NexoryColors.SurfaceMid)
                Spacer(Modifier.height(8.dp))
                ProfileMenuItem(
                    icon    = Icons.Default.Logout,
                    label   = "Выйти из аккаунта",
                    color   = NexoryColors.Error,
                    onClick = { showLogoutDialog = true },
                )
            }
        }
    }

    if (showEditDialog) {
        EditProfileDialog(
            currentUsername = uiState.user?.username ?: "",
            currentBio      = uiState.user?.bio ?: "",
            onDismiss = { showEditDialog = false },
            onConfirm = { username, bio ->
                viewModel.updateProfile(username, bio, null)
                showEditDialog = false
            }
        )
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            containerColor   = NexoryColors.SurfaceDark,
            title  = { Text("Выйти?", color = NexoryColors.TextPrimary) },
            text   = {
                Text(
                    "Вы действительно хотите выйти из аккаунта?",
                    color = NexoryColors.TextSecondary,
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.logout(); showLogoutDialog = false },
                    colors  = ButtonDefaults.buttonColors(containerColor = NexoryColors.Error),
                ) { Text("Выйти") }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("Отмена", color = NexoryColors.PrimaryBlue)
                }
            }
        )
    }
}

@Composable
fun ProfileMenuItem(
    icon:    ImageVector,
    label:   String,
    color:   Color,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(NexoryColors.SurfaceDark)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(color.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(14.dp))
        Text(
            text     = label,
            fontSize = 15.sp,
            color    = NexoryColors.TextPrimary,
            modifier = Modifier.weight(1f),
        )
        Icon(
            Icons.Default.ChevronRight, null,
            tint     = NexoryColors.TextSecondary,
            modifier = Modifier.size(20.dp),
        )
    }
}

@Composable
fun EditProfileDialog(
    currentUsername: String,
    currentBio:      String,
    onDismiss:       () -> Unit,
    onConfirm:       (String, String) -> Unit,
) {
    var username by remember { mutableStateOf(currentUsername) }
    var bio      by remember { mutableStateOf(currentBio) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = NexoryColors.SurfaceDark,
        title  = { Text("Редактировать профиль", color = NexoryColors.TextPrimary) },
        text   = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value         = username,
                    onValueChange = { username = it },
                    label         = { Text("Имя пользователя") },
                    singleLine    = true,
                    modifier      = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value         = bio,
                    onValueChange = { bio = it },
                    label         = { Text("О себе") },
                    maxLines      = 3,
                    modifier      = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(username, bio) },
                colors  = ButtonDefaults.buttonColors(containerColor = NexoryColors.PrimaryBlue),
            ) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = NexoryColors.TextSecondary)
            }
        }
    )
}