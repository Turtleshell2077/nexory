package com.nexory.app.ui.screens.events

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.nexory.app.ui.theme.NexoryColors

val EVENT_CATEGORIES = listOf("🎵 Музыка", "⚽ Спорт", "🍕 Еда", "🎨 Искусство", "🎮 Игры", "🌿 Природа", "📚 Образование", "🎉 Вечеринка")

@Composable
fun CreateEventScreen(
    navController: NavController,
    viewModel: CreateEventViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState.isCreated) {
        if (uiState.isCreated) navController.popBackStack()
    }

    var title       by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var address     by remember { mutableStateOf("") }
    var category    by remember { mutableStateOf("") }
    var startsAt    by remember { mutableStateOf("") }
    var maxParticipants by remember { mutableStateOf("") }
    var isPrivate   by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = NexoryColors.DeepBlack,
        topBar = {
            TopAppBar(
                title = { Text("Новое мероприятие", color = NexoryColors.TextPrimary, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.Close, null, tint = NexoryColors.TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoryColors.SurfaceDark),
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {

            SectionLabel("Основная информация")

            NexoryField(value = title, onValueChange = { title = it },
                label = "Название *", icon = Icons.Default.Title)

            NexoryField(value = description, onValueChange = { description = it },
                label = "Описание", icon = Icons.Default.Description, maxLines = 5)

            SectionLabel("Место и время")

            NexoryField(value = address, onValueChange = { address = it },
                label = "Адрес *", icon = Icons.Default.LocationOn)

            // Дата и время — простое текстовое поле (в продакшне → DateTimePicker)
            NexoryField(
                value = startsAt, onValueChange = { startsAt = it },
                label = "Дата и время (YYYY-MM-DDTHH:MM) *",
                icon = Icons.Default.CalendarToday,
            )

            SectionLabel("Дополнительно")

            // Выбор категории
            ExposedDropdownMenuBox(
                expanded = categoryExpanded,
                onExpandedChange = { categoryExpanded = it },
            ) {
                OutlinedTextField(
                    value = category,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    label = { Text("Категория") },
                    leadingIcon = { Icon(Icons.Default.Category, null) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                    shape = RoundedCornerShape(12.dp),
                    colors = nexoryTextFieldColors(),
                )
                ExposedDropdownMenu(
                    expanded = categoryExpanded,
                    onDismissRequest = { categoryExpanded = false },
                ) {
                    EVENT_CATEGORIES.forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat, color = NexoryColors.TextPrimary) },
                            onClick = { category = cat; categoryExpanded = false },
                        )
                    }
                }
            }

            NexoryField(
                value = maxParticipants, onValueChange = { maxParticipants = it },
                label = "Макс. участников (пусто = без ограничений)",
                icon = Icons.Default.People,
                keyboardType = KeyboardType.Number,
            )

            // Приватность
            Row(
                modifier = Modifier.fillMaxWidth()
                    .background(NexoryColors.SurfaceDark, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Default.Lock, null, tint = NexoryColors.TextSecondary)
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Приватное мероприятие", color = NexoryColors.TextPrimary, fontSize = 15.sp)
                    Text("Видно только друзьям", color = NexoryColors.TextSecondary, fontSize = 12.sp)
                }
                Switch(
                    checked = isPrivate,
                    onCheckedChange = { isPrivate = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor  = Color.White,
                        checkedTrackColor  = NexoryColors.DeepBlue,
                        uncheckedTrackColor = NexoryColors.SurfaceMid,
                    )
                )
            }

            uiState.error?.let {
                Text(it, color = NexoryColors.Error, fontSize = 13.sp)
            }

            Spacer(Modifier.height(8.dp))

            // Кнопка создания
            Button(
                onClick = {
                    viewModel.createEvent(
                        title       = title,
                        description = description.takeIf { it.isNotBlank() },
                        address     = address,
                        category    = category.takeIf { it.isNotBlank() },
                        startsAt    = startsAt,
                        maxParticipants = maxParticipants.toIntOrNull(),
                        isPrivate   = isPrivate,
                    )
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled  = !uiState.isLoading && title.isNotBlank() && address.isNotBlank() && startsAt.isNotBlank(),
                shape    = RoundedCornerShape(14.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues(0.dp),
            ) {
                Box(
                    modifier = Modifier.fillMaxSize().background(
                        if (!uiState.isLoading)
                            Brush.linearGradient(listOf(NexoryColors.GradientStart, NexoryColors.GradientEnd))
                        else Brush.linearGradient(listOf(NexoryColors.SurfaceMid, NexoryColors.SurfaceMid))
                    ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (uiState.isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Text("Создать мероприятие", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        color = NexoryColors.TextSecondary,
        modifier = Modifier.padding(top = 4.dp))
}

@Composable
fun NexoryField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    maxLines: Int = 1,
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        leadingIcon = { Icon(icon, null) },
        maxLines = maxLines,
        singleLine = maxLines == 1,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(12.dp),
        colors = nexoryTextFieldColors(),
    )
}