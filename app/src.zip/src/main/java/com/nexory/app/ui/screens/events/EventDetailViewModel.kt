data class EventDetailUiState(
    val event: com.nexory.app.data.network.EventDto? = null,
    val participants: List<com.nexory.app.data.network.FriendDto> = emptyList(),
    val isJoined: Boolean = false,
    val isMyEvent: Boolean = false,
    val eventChatId: String? = null,
    val isLoading: Boolean = false,
)

@HiltViewModel
class EventDetailViewModel @Inject constructor(
    private val api: NexoryApi,
    private val tokenManager: TokenManager,
) : ViewModel() {
    private val _state = MutableStateFlow(EventDetailUiState())
    val uiState = _state.asStateFlow()

    fun loadEvent(eventId: String) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val response = api.getEvent(eventId)
                val event = response["event"] ?: return@launch
                val userId = tokenManager.getUserId()
                _state.update { it.copy(
                    event     = event,
                    isMyEvent = event.creatorId == userId,
                    isLoading = false,
                )}
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false) }
            }
        }
    }

    fun joinEvent(eventId: String) {
        viewModelScope.launch {
            try { api.joinEvent(eventId); _state.update { it.copy(isJoined = true) } } catch (_: Exception) {}
        }
    }

    fun leaveEvent(eventId: String) {
        viewModelScope.launch {
            try { api.leaveEvent(eventId); _state.update { it.copy(isJoined = false) } } catch (_: Exception) {}
        }
    }
}